import 'package:shared_preferences/shared_preferences.dart';

class CacheHelper {
  static late SharedPreferences sharedPreferences;

  static Future<void> init() async {
    sharedPreferences = await SharedPreferences.getInstance();
  }

  static Future<bool> saveData({
    required String key,
    required dynamic value,
  }) async {
    if (value == null) return await removeData(key: key);

    if (value is String) return await sharedPreferences.setString(key, value);
    if (value is int) return await sharedPreferences.setInt(key, value);
    if (value is bool) return await sharedPreferences.setBool(key, value);
    return await sharedPreferences.setDouble(key, value);
  }

  static dynamic getData({required String key}) {
    return sharedPreferences.get(key);
  }

  static Future<bool> removeData({required String key}) async {
    return await sharedPreferences.remove(key);
  }

  static Future<void> removeByPrefixes(List<String> prefixes) async {
    for (final key in sharedPreferences.getKeys().toList()) {
      if (prefixes.any(key.startsWith)) {
        await sharedPreferences.remove(key);
      }
    }
  }

  static Future<bool> clearData() async {
    return await sharedPreferences.clear();
  }
}
